package a;

public class Monkey extends Omnivorous {

    public Monkey(String name, String weight) {
        super(name, weight);
    }
}
