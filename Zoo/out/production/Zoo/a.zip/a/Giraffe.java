package a;

public class Giraffe extends Herbivore {

    public Giraffe(String name, String weight) {
        super(name, weight);
    }
}
