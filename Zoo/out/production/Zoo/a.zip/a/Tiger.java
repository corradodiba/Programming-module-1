package a;

public class Tiger extends Carnivorous {

    public Tiger(String name, String weight) {
        super(name, weight);
    }
}
