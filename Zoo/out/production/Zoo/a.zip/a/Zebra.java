package a;

public class Zebra extends Herbivore {

    public Zebra(String name, String weight) {
        super(name, weight);
    }
}
